-- Tracewise schema (PostgreSQL)
CREATE TABLE nav_tab (
  id          serial PRIMARY KEY,
  slug        text UNIQUE NOT NULL,
  label       text NOT NULL,
  kind        text NOT NULL CHECK (kind IN ('notes','solutions','custom')),
  sort_order  int  NOT NULL DEFAULT 0,
  is_active   boolean NOT NULL DEFAULT true
);

CREATE TABLE nav_subpage (
  id          serial PRIMARY KEY,
  tab_id      int NOT NULL REFERENCES nav_tab(id) ON DELETE CASCADE,
  slug        text NOT NULL,
  label       text NOT NULL,
  sort_order  int  NOT NULL DEFAULT 0,
  UNIQUE (tab_id, slug)
);

CREATE TABLE note (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id   uuid REFERENCES note(id) ON DELETE CASCADE,
  title       text NOT NULL,
  is_folder   boolean NOT NULL DEFAULT false,
  body_md     text NOT NULL DEFAULT '',
  sort_order  int  NOT NULL DEFAULT 0,
  updated_at  timestamptz NOT NULL DEFAULT now()
);

-- Nav query used to build the top nav
SELECT t.id, t.slug, t.label, t.kind,
       COALESCE(json_agg(s ORDER BY s.sort_order) FILTER (WHERE s.id IS NOT NULL), '[]') AS subpages
FROM nav_tab t
LEFT JOIN nav_subpage s ON s.tab_id = t.id
WHERE t.is_active
GROUP BY t.id
ORDER BY t.sort_order;
