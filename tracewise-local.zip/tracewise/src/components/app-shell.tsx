import { useMemo, useState } from "react";
import { Outlet, useLocation } from "react-router-dom";
import { motion } from "motion/react";
import { ArrowDown, ArrowUp, ChevronDown, Database, Plus, Trash2 } from "lucide-react";
import { Toaster } from "@/components/ui/sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Sheet, SheetContent, SheetDescription, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { nextId, SCHEMA_SQL, selectNav, slugify, useSite } from "@/data/site";

function TraceMark() {
  return (
    <svg viewBox="0 0 32 32" className="size-7" aria-hidden="true">
      <rect x="1" y="1" width="30" height="30" rx="7" className="fill-primary" />
      <path
        d="M4 19 H10 L12.5 9 L16 24 L19 13 L21 19 H28"
        fill="none"
        stroke="currentColor"
        strokeWidth="2.2"
        strokeLinecap="round"
        strokeLinejoin="round"
        className="tw-trace text-primary-foreground"
      />
    </svg>
  );
}

function TopNav() {
  const db = useSite((s) => s.db);
  const focus = useSite((s) => s.focus);
  const goTo = useSite((s) => s.goTo);
  const nav = useMemo(() => selectNav(db), [db]);

  return (
    <header className="sticky top-0 z-40 border-b border-border bg-background/85 backdrop-blur">
      <a
        href="#main-work"
        className="sr-only focus:not-sr-only focus:absolute focus:left-3 focus:top-3 focus:z-50 focus:rounded-md focus:bg-card focus:px-3 focus:py-2"
      >
        Skip to content
      </a>
      <div className="mx-auto flex h-14 max-w-7xl items-center gap-3 px-4 sm:px-6">
        <button
          type="button"
          onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
          className="flex shrink-0 items-center gap-2 rounded-md pr-2 outline-none focus-visible:ring-2 focus-visible:ring-ring"
          aria-label="Tracewise, back to top"
        >
          <TraceMark />
          <span className="hidden font-mono text-sm font-semibold tracking-tight sm:inline">
            trace<span className="text-primary">wise</span>
          </span>
        </button>

        <nav aria-label="Site sections" className="no-scrollbar -mx-1 flex min-w-0 flex-1 items-center gap-1 overflow-x-auto px-1">
          {nav.map((tab, i) => {
            const active = focus?.tab === tab.slug;
            return (
              <DropdownMenu key={tab.id}>
                <DropdownMenuTrigger asChild>
                  <Button
                    variant="ghost"
                    size="sm"
                    aria-current={active ? "location" : undefined}
                    className={`shrink-0 gap-1.5 font-medium ${active ? "bg-muted text-foreground" : ""}`}
                  >
                    <span className="font-mono text-[11px] text-muted-foreground">{String(i + 1).padStart(2, "0")}</span>
                    {tab.label}
                    <ChevronDown className="size-3.5 opacity-70" aria-hidden="true" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="min-w-52">
                  <DropdownMenuItem onSelect={() => goTo(tab.slug, null)}>All of {tab.label}</DropdownMenuItem>
                  {tab.subpages.length > 0 && (
                    <>
                      <DropdownMenuSeparator />
                      <DropdownMenuLabel className="font-mono text-[11px] uppercase tracking-wider text-muted-foreground">
                        Subpages
                      </DropdownMenuLabel>
                    </>
                  )}
                  {tab.subpages.map((s) => (
                    <DropdownMenuItem key={s.id} onSelect={() => goTo(tab.slug, s.slug)}>
                      {s.label}
                    </DropdownMenuItem>
                  ))}
                </DropdownMenuContent>
              </DropdownMenu>
            );
          })}
        </nav>

        <SiteTables />
      </div>
    </header>
  );
}

function SiteTables() {
  const db = useSite((s) => s.db);
  const mutate = useSite((s) => s.mutate);
  const all = useMemo(() => selectNav(db, true), [db]);
  const [newTab, setNewTab] = useState("");
  const [newSub, setNewSub] = useState<Record<number, string>>({});
  const [showSql, setShowSql] = useState(false);

  const addTab = () => {
    const label = newTab.trim();
    if (!label) return;
    mutate((d) => {
      const id = nextId(d.nav_tab);
      let slug = slugify(label);
      if (d.nav_tab.some((t) => t.slug === slug)) slug = `${slug}-${id}`;
      return {
        ...d,
        nav_tab: [...d.nav_tab, { id, slug, label, kind: "custom", sort_order: d.nav_tab.length + 1, is_active: true }],
      };
    });
    setNewTab("");
  };

  const addSub = (tabId: number) => {
    const label = (newSub[tabId] ?? "").trim();
    if (!label) return;
    mutate((d) => {
      const id = nextId(d.nav_subpage);
      const siblings = d.nav_subpage.filter((s) => s.tab_id === tabId);
      let slug = slugify(label);
      if (siblings.some((s) => s.slug === slug)) slug = `${slug}-${id}`;
      return {
        ...d,
        nav_subpage: [...d.nav_subpage, { id, tab_id: tabId, slug, label, sort_order: siblings.length + 1 }],
      };
    });
    setNewSub((m) => ({ ...m, [tabId]: "" }));
  };

  const move = (id: number, dir: -1 | 1) =>
    mutate((d) => {
      const sorted = [...d.nav_tab].sort((a, b) => a.sort_order - b.sort_order);
      const i = sorted.findIndex((t) => t.id === id);
      const j = i + dir;
      if (i < 0 || j < 0 || j >= sorted.length) return d;
      [sorted[i], sorted[j]] = [sorted[j], sorted[i]];
      return { ...d, nav_tab: sorted.map((t, k) => ({ ...t, sort_order: k + 1 })) };
    });

  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="outline" size="sm" className="shrink-0 gap-1.5">
          <Database className="size-4" aria-hidden="true" />
          <span className="hidden sm:inline">Site tables</span>
          <span className="sr-only sm:hidden">Site tables</span>
        </Button>
      </SheetTrigger>
      <SheetContent className="w-full overflow-y-auto sm:max-w-lg">
        <SheetHeader>
          <SheetTitle className="font-serif text-xl">Site tables</SheetTitle>
          <SheetDescription className="font-mono text-xs">
            nav_tab · {db.nav_tab.length} rows — nav_subpage · {db.nav_subpage.length} rows
          </SheetDescription>
        </SheetHeader>

        <div className="space-y-4 px-4 pb-6">
          <ul className="divide-y divide-border rounded-lg border border-border">
            {all.map((t, i) => (
              <li key={t.id} className="p-3">
                <div className="flex items-center gap-1.5">
                  <span className="w-6 font-mono text-xs text-muted-foreground">{t.id}</span>
                  <div className="min-w-0 flex-1">
                    <p className="truncate font-medium">{t.label}</p>
                    <p className="font-mono text-xs text-muted-foreground">
                      /{t.slug} · {t.kind}
                    </p>
                  </div>
                  <Button variant="ghost" size="icon-sm" aria-label={`Move ${t.label} up`} disabled={i === 0} onClick={() => move(t.id, -1)}>
                    <ArrowUp aria-hidden="true" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon-sm"
                    aria-label={`Move ${t.label} down`}
                    disabled={i === all.length - 1}
                    onClick={() => move(t.id, 1)}
                  >
                    <ArrowDown aria-hidden="true" />
                  </Button>
                  <Switch
                    checked={t.is_active}
                    aria-label={`Show ${t.label} in the top nav`}
                    onCheckedChange={(v) =>
                      mutate((d) => ({ ...d, nav_tab: d.nav_tab.map((x) => (x.id === t.id ? { ...x, is_active: v } : x)) }))
                    }
                  />
                  {t.kind === "custom" && (
                    <Button
                      variant="ghost"
                      size="icon-sm"
                      aria-label={`Delete ${t.label}`}
                      onClick={() =>
                        mutate((d) => ({
                          ...d,
                          nav_tab: d.nav_tab.filter((x) => x.id !== t.id),
                          nav_subpage: d.nav_subpage.filter((s) => s.tab_id !== t.id),
                        }))
                      }
                    >
                      <Trash2 aria-hidden="true" />
                    </Button>
                  )}
                </div>
                <div className="mt-2 flex flex-wrap items-center gap-1.5 pl-7">
                  {t.subpages.map((s) => (
                    <span key={s.id} className="inline-flex items-center gap-1 rounded-md border border-border bg-muted px-2 py-0.5 text-xs">
                      {s.label}
                      <button
                        type="button"
                        aria-label={`Remove subpage ${s.label}`}
                        className="rounded-sm px-0.5 text-foreground/70 hover:text-foreground focus-visible:outline-2 focus-visible:outline-ring"
                        onClick={() => mutate((d) => ({ ...d, nav_subpage: d.nav_subpage.filter((x) => x.id !== s.id) }))}
                      >
                        ×
                      </button>
                    </span>
                  ))}
                  <form
                    className="flex items-center gap-1"
                    onSubmit={(e) => {
                      e.preventDefault();
                      addSub(t.id);
                    }}
                  >
                    <Input
                      value={newSub[t.id] ?? ""}
                      onChange={(e) => setNewSub((m) => ({ ...m, [t.id]: e.target.value }))}
                      placeholder="New subpage"
                      aria-label={`New subpage for ${t.label}`}
                      className="h-7 w-32 text-xs"
                    />
                    <Button type="submit" variant="ghost" size="icon-xs" aria-label={`Add subpage to ${t.label}`}>
                      <Plus aria-hidden="true" />
                    </Button>
                  </form>
                </div>
              </li>
            ))}
          </ul>

          <form
            className="flex gap-2"
            onSubmit={(e) => {
              e.preventDefault();
              addTab();
            }}
          >
            <Input value={newTab} onChange={(e) => setNewTab(e.target.value)} placeholder="New tab label" aria-label="New tab label" />
            <Button type="submit" className="gap-1.5">
              <Plus className="size-4" aria-hidden="true" /> Add tab
            </Button>
          </form>

          <div>
            <Button variant="ghost" size="sm" aria-expanded={showSql} onClick={() => setShowSql((v) => !v)} className="gap-1.5 px-2">
              <ChevronDown className={`size-4 transition-transform ${showSql ? "rotate-180" : ""}`} aria-hidden="true" />
              PostgreSQL schema
            </Button>
            {showSql && (
              <pre className="mt-2 max-h-80 overflow-auto rounded-lg border border-border bg-muted p-3 font-mono text-[11px] leading-relaxed">
                {SCHEMA_SQL}
              </pre>
            )}
          </div>
        </div>
      </SheetContent>
    </Sheet>
  );
}

export function AppShell() {
  const { pathname } = useLocation();
  return (
    <div className="flex min-h-screen flex-col">
      <TopNav />
      <main className="flex flex-1 flex-col">
        <motion.div
          key={pathname}
          initial={{ opacity: 0, y: 6 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.15, ease: "easeOut" }}
          className="flex-1"
        >
          <Outlet />
        </motion.div>
      </main>
      <Toaster />
    </div>
  );
}

export default AppShell;
