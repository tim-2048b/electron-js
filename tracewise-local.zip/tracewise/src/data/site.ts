import { create } from "zustand";

/* ------------------------------------------------------------------ *
 * Tables — mirror db/schema.sql (PostgreSQL). In this build the rows
 * live in the browser; swap `loadDb`/`writeDb` for an API later.
 * ------------------------------------------------------------------ */

export type TabKind = "notes" | "solutions" | "custom";

export interface NavTab {
  id: number;
  slug: string;
  label: string;
  kind: TabKind;
  sort_order: number;
  is_active: boolean;
}

export interface NavSubpage {
  id: number;
  tab_id: number;
  slug: string;
  label: string;
  sort_order: number;
}

export interface Note {
  id: string;
  parent_id: string | null;
  title: string;
  is_folder: boolean;
  body_md: string;
  sort_order: number;
  updated_at: string;
}

export interface SolutionStep {
  title: string;
  detail: string;
  code?: string;
  lang?: string;
}

export interface Solution {
  id: string;
  category: "evt" | "logparse" | "powershell" | "python";
  title: string;
  summary: string;
  tags: string[];
  steps: SolutionStep[];
}

interface DbPayload {
  v: 1;
  nav_tab: NavTab[];
  nav_subpage: NavSubpage[];
  note: Note[];
}

export const STORAGE_KEY = "aether:9f6385c3-c239-4044-bc51-93cb985bfa4e:records";

export const slugify = (s: string) =>
  s
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-|-$/g, "") || "item";

const now = () => new Date().toISOString();

/* ---------------------------- seed rows ---------------------------- */

const SEED_TABS: NavTab[] = [
  { id: 1, slug: "notes", label: "Notes", kind: "notes", sort_order: 1, is_active: true },
  { id: 2, slug: "solutions", label: "Solutions", kind: "solutions", sort_order: 2, is_active: true },
  { id: 3, slug: "case-journal", label: "Case Journal", kind: "custom", sort_order: 3, is_active: false },
  { id: 4, slug: "sharepoint-farm", label: "SharePoint Farm", kind: "custom", sort_order: 4, is_active: false },
  { id: 5, slug: "office-client", label: "Office Client", kind: "custom", sort_order: 5, is_active: false },
  { id: 6, slug: "log-lab", label: "Log Lab", kind: "custom", sort_order: 6, is_active: false },
];

const sp = (id: number, tab_id: number, label: string, sort_order: number, slug?: string): NavSubpage => ({
  id,
  tab_id,
  label,
  sort_order,
  slug: slug ?? slugify(label),
});

const SEED_SUBPAGES: NavSubpage[] = [
  sp(1, 1, "SharePoint", 1),
  sp(2, 1, "Office Client", 2),
  sp(3, 1, "Scratchpad", 3),
  sp(4, 2, "Event Logs", 1, "evt"),
  sp(5, 2, "Log Parsing", 2, "logparse"),
  sp(6, 2, "PowerShell", 3, "powershell"),
  sp(7, 2, "Python Diagrams", 4, "python"),
  sp(8, 3, "Open cases", 1),
  sp(9, 3, "Closed cases", 2),
  sp(10, 3, "Customer replies", 3),
  sp(11, 4, "Office Online Server", 1),
  sp(12, 4, "User Profile Sync", 2),
  sp(13, 4, "Distributed Cache", 3),
  sp(14, 4, "Search Crawl", 4),
  sp(15, 5, "Activation & KMS", 1),
  sp(16, 5, "Install & ODT", 2),
  sp(17, 5, "Paste hang & add-ins", 3),
  sp(18, 6, "ULS", 1),
  sp(19, 6, "Network trace", 2),
  sp(20, 6, "AI inspection", 3),
];

const n = (
  id: string,
  parent_id: string | null,
  title: string,
  sort_order: number,
  body_md = "",
  is_folder = false,
): Note => ({ id, parent_id, title, sort_order, body_md, is_folder, updated_at: "2026-11-10T08:00:00.000Z" });

const SEED_NOTES: Note[] = [
  n("f-sp", null, "SharePoint", 1, "", true),
  n("f-oos", "f-sp", "Office Online Server", 1, "", true),
  n(
    "n-oos-cert",
    "f-oos",
    "OOS cert not found",
    1,
    `# OOS cert not found

**Symptom** — \`New-OfficeWebAppsFarm\` fails: *certificate not found*.

## Checks
1. Friendly name matches \`-CertificateName\`
2. Cert sits in **LocalMachine\\My** with a private key
3. SAN covers the farm URL

\`\`\`powershell
Get-ChildItem Cert:\\LocalMachine\\My | Select FriendlyName, Subject, NotAfter
\`\`\`

**Next:** re-import with private key, then re-run farm creation.`,
  ),
  n(
    "n-upa",
    "f-sp",
    "UPA group discovery fail",
    2,
    `# UPA group discovery fail

| Item | Value |
| --- | --- |
| Service | User Profile Service |
| Job | User Profile to SharePoint Full Synchronization |

Check the **sync connection** filter, then rerun the timer job.`,
  ),
  n(
    "n-dc",
    "f-sp",
    "Distributed Cache revision fail",
    3,
    `# Distributed Cache revision fail

\`\`\`powershell
Use-CacheCluster
Get-CacheHost
\`\`\`

> Stop the cache host gracefully before any patching.`,
  ),
  n("f-office", null, "Office Client", 2, "", true),
  n(
    "n-kms",
    "f-office",
    "KMS activation failed",
    1,
    `# KMS activation failed

\`\`\`cmd
cscript ospp.vbs /dstatus
cscript ospp.vbs /act
\`\`\`

Error **0xC004F074** → KMS host unreachable. Check DNS SRV \`_vlmcs._tcp\`.`,
  ),
  n(
    "n-paste",
    "f-office",
    "Paste hang",
    2,
    `# Paste hang

- Start Excel with \`/safe\`
- Disable COM add-ins one at a time
- Capture a **Procmon** trace during the paste`,
  ),
  n("f-scratch", null, "Scratchpad", 3, "", true),
  n(
    "n-welcome",
    "f-scratch",
    "How this index works",
    1,
    `# Notes index

Drop **.md** files onto the index to import them. Drag a note onto a folder to file it.

\`\`\`text
SharePoint/
  Office Online Server/
    OOS cert not found.md
\`\`\``,
  ),
];

/* --------------------------- solutions ----------------------------- */

export const SOLUTIONS: Solution[] = [
  {
    id: "evt-crash",
    category: "evt",
    title: "Application crash triage",
    summary: "Pull Application log errors around the crash window and pin the faulting module.",
    tags: ["Event 1000", "Event 1026", "evtx"],
    steps: [
      { title: "Export", detail: "Save the Application log from the affected machine.", code: "wevtutil epl Application C:\\temp\\app.evtx", lang: "cmd" },
      {
        title: "Filter",
        detail: "Keep errors from Application Error and .NET Runtime in the last 24 hours.",
        code: "Get-WinEvent -FilterHashtable @{LogName='Application'; Level=2; StartTime=(Get-Date).AddDays(-1)} |\n  Where-Object ProviderName -in 'Application Error','.NET Runtime'",
        lang: "powershell",
      },
      { title: "Correlate", detail: "Line up each event with the user-reported time and the faulting module path." },
      { title: "Conclude", detail: "Faulting module in a third-party DLL → isolate with add-ins disabled or clean boot." },
    ],
  },
  {
    id: "evt-sync",
    category: "evt",
    title: "OneNote / OneDrive sync failure",
    summary: "Read the client logs and Application events that fire during sync to isolate the blocker.",
    tags: ["sync", "0xE0001475"],
    steps: [
      { title: "Reproduce", detail: "Trigger a sync and note the exact error code shown in the client." },
      { title: "Collect", detail: "Gather Application events from the same minute.", code: "Get-WinEvent -LogName Application -MaxEvents 200 |\n  Where-Object TimeCreated -gt (Get-Date).AddMinutes(-10)", lang: "powershell" },
      { title: "Isolate", detail: "Remove and re-add the notebook; compare behaviour on a second machine." },
    ],
  },
  {
    id: "uls-correlation",
    category: "logparse",
    title: "ULS correlation trace",
    summary: "Merge farm ULS logs by correlation ID and read the High / Unexpected lines in order.",
    tags: ["ULS", "Merge-SPLogFile"],
    steps: [
      { title: "Capture ID", detail: "Copy the correlation ID from the SharePoint error page." },
      {
        title: "Merge",
        detail: "Merge every server's ULS entries for that ID into one file.",
        code: "Merge-SPLogFile -Path C:\\temp\\merged.log -Correlation <guid> -Overwrite",
        lang: "powershell",
      },
      { title: "Filter", detail: "Keep Level = High, Unexpected, Critical; group by Category." },
      { title: "Timeline", detail: "Read top-down: the first Unexpected line is usually the root cause." },
    ],
  },
  {
    id: "iis-logparser",
    category: "logparse",
    title: "IIS slow request sweep",
    summary: "Rank the slowest URLs from IIS logs to find the page or service behind a slowdown.",
    tags: ["LogParser", "IIS", "time-taken"],
    steps: [
      {
        title: "Query",
        detail: "Top 20 slowest requests.",
        code: "LogParser.exe \"SELECT TOP 20 cs-uri-stem, time-taken FROM u_ex*.log ORDER BY time-taken DESC\" -i:IISW3C",
        lang: "cmd",
      },
      { title: "Group", detail: "Group by cs-uri-stem and average time-taken to separate one-offs from patterns." },
      { title: "Cross-check", detail: "Match the slow window against ULS and the SQL server's waits." },
    ],
  },
  {
    id: "ps-farm-health",
    category: "powershell",
    title: "Farm health sweep",
    summary: "One pass over servers, service instances and content databases, exported to CSV.",
    tags: ["SharePoint", "health"],
    steps: [
      { title: "Servers", detail: "List servers and their role.", code: "Get-SPServer | Select Name, Role, Status", lang: "powershell" },
      {
        title: "Services",
        detail: "Find services that are not Online.",
        code: "Get-SPServiceInstance | Where-Object Status -ne 'Online' |\n  Select TypeName, Server, Status",
        lang: "powershell",
      },
      { title: "Databases", detail: "Check content databases for upgrade needs.", code: "Get-SPContentDatabase | Test-SPContentDatabase", lang: "powershell" },
      { title: "Export", detail: "Pipe results to Export-Csv for the case record." },
    ],
  },
  {
    id: "py-diagram",
    category: "python",
    title: "Event flow diagram",
    summary: "Turn an exported event CSV into a timeline and a flow diagram for the customer report.",
    tags: ["pandas", "matplotlib", "mermaid"],
    steps: [
      {
        title: "Load",
        detail: "Read the exported events.",
        code: "import pandas as pd\ndf = pd.read_csv('events.csv', parse_dates=['TimeCreated'])",
        lang: "python",
      },
      { title: "Group", detail: "Count events per provider per minute.", code: "df.groupby([pd.Grouper(key='TimeCreated', freq='1min'), 'ProviderName']).size()", lang: "python" },
      {
        title: "Diagram",
        detail: "Emit a Mermaid flow of provider → event ID.",
        code: "lines = ['flowchart LR'] + [f'  {p} --> E{i}' for p, i in df[['ProviderName','Id']].drop_duplicates().values]\nprint('\\n'.join(lines))",
        lang: "python",
      },
    ],
  },
];

/* ------------------------- persistence ----------------------------- */

const seed = (): DbPayload => ({ v: 1, nav_tab: SEED_TABS, nav_subpage: SEED_SUBPAGES, note: SEED_NOTES });

const isPayload = (x: unknown): x is DbPayload => {
  if (!x || typeof x !== "object") return false;
  const p = x as Record<string, unknown>;
  return Array.isArray(p.nav_tab) && Array.isArray(p.nav_subpage) && Array.isArray(p.note);
};

type LoadResult = { db: DbPayload; status: "ok" | "unavailable" | "invalid" };

function loadDb(): LoadResult {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (raw === null) return { db: seed(), status: "ok" };
    const parsed: unknown = JSON.parse(raw);
    if (!isPayload(parsed)) return { db: seed(), status: "invalid" };
    return { db: { ...parsed, v: 1 }, status: "ok" };
  } catch {
    return { db: seed(), status: "unavailable" };
  }
}

function readFresh(): DbPayload | null {
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (raw === null) return null;
    const parsed: unknown = JSON.parse(raw);
    return isPayload(parsed) ? parsed : null;
  } catch {
    return null;
  }
}

export type SaveState = "idle" | "saved" | "failed" | "load-failed";

export interface Focus {
  tab: string;
  sub: string | null;
  at: number;
}

interface SiteState {
  db: DbPayload;
  save: SaveState;
  focus: Focus | null;
  selectedNoteId: string | null;
  /** apply a mutation to the freshest copy of the tables and persist */
  mutate: (fn: (db: DbPayload) => DbPayload) => void;
  reload: () => void;
  goTo: (tab: string, sub?: string | null) => void;
  selectNote: (id: string | null) => void;
}

const initial = loadDb();

export const useSite = create<SiteState>((set, get) => ({
  db: initial.db,
  save: initial.status === "ok" ? "idle" : initial.status === "invalid" ? "load-failed" : "failed",
  focus: null,
  selectedNoteId: "n-oos-cert",
  mutate: (fn) => {
    const state = get();
    // Saved data that couldn't be read is never overwritten.
    const base = state.save === "load-failed" ? state.db : (readFresh() ?? state.db);
    const next = fn(base);
    set({ db: next });
    if (state.save === "load-failed") return;
    try {
      window.localStorage.setItem(STORAGE_KEY, JSON.stringify(next));
      set({ save: "saved" });
    } catch {
      set({ save: "failed" });
    }
  },
  reload: () => {
    const fresh = readFresh();
    if (fresh) set({ db: fresh });
  },
  goTo: (tab, sub = null) => {
    set({ focus: { tab, sub, at: Date.now() } });
    requestAnimationFrame(() => {
      document.getElementById(`tab-${tab}`)?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  },
  selectNote: (id) => set({ selectedNoteId: id }),
}));

try {
  window.addEventListener("storage", (e) => {
    if (e.key === STORAGE_KEY) useSite.getState().reload();
  });
} catch {
  /* storage events unavailable */
}

/* ---------------------- nav query (the "SELECT") -------------------- */

export interface NavEntry extends NavTab {
  subpages: NavSubpage[];
}

/** SELECT t.*, json_agg(s ORDER BY s.sort_order) FROM nav_tab t
 *  LEFT JOIN nav_subpage s ON s.tab_id = t.id WHERE t.is_active
 *  GROUP BY t.id ORDER BY t.sort_order; */
export function selectNav(db: DbPayload, includeInactive = false): NavEntry[] {
  return [...db.nav_tab]
    .filter((t) => includeInactive || t.is_active)
    .sort((a, b) => a.sort_order - b.sort_order)
    .map((t) => ({
      ...t,
      subpages: db.nav_subpage.filter((s) => s.tab_id === t.id).sort((a, b) => a.sort_order - b.sort_order),
    }));
}

export const nextId = (rows: { id: number }[]) => rows.reduce((m, r) => Math.max(m, r.id), 0) + 1;
export const newNoteId = () => `n-${Math.random().toString(36).slice(2, 10)}`;
export const stamp = now;

export const SCHEMA_SQL = `CREATE TABLE nav_tab (
  id          serial PRIMARY KEY,
  slug        text UNIQUE NOT NULL,
  label       text NOT NULL,
  kind        text NOT NULL CHECK (kind IN ('notes','solutions','custom')),
  sort_order  int  NOT NULL DEFAULT 0,
  is_active   boolean NOT NULL DEFAULT true
);

CREATE TABLE nav_subpage (
  id          serial PRIMARY KEY,
  tab_id      int NOT NULL REFERENCES nav_tab(id) ON DELETE CASCADE,
  slug        text NOT NULL,
  label       text NOT NULL,
  sort_order  int  NOT NULL DEFAULT 0,
  UNIQUE (tab_id, slug)
);

CREATE TABLE note (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  parent_id   uuid REFERENCES note(id) ON DELETE CASCADE,
  title       text NOT NULL,
  is_folder   boolean NOT NULL DEFAULT false,
  body_md     text NOT NULL DEFAULT '',
  sort_order  int  NOT NULL DEFAULT 0,
  updated_at  timestamptz NOT NULL DEFAULT now()
);`;
