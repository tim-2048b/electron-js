import { useEffect, useMemo, useRef, useState, type ChangeEvent, type DragEvent as ReactDragEvent, type ReactNode } from "react";
import { AnimatePresence, motion } from "motion/react";
import {
  DndContext,
  KeyboardSensor,
  PointerSensor,
  useDraggable,
  useDroppable,
  useSensor,
  useSensors,
  type DragEndEvent,
} from "@dnd-kit/core";
import {
  ChevronDown,
  ChevronRight,
  Copy,
  Download,
  FileText,
  Folder,
  FolderOpen,
  FolderPlus,
  GripVertical,
  HardDrive,
  Plus,
  Trash2,
  Upload,
} from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { MarkdownText } from "@/components/markdown-text";
import {
  newNoteId,
  selectNav,
  slugify,
  SOLUTIONS,
  stamp,
  useSite,
  type NavEntry,
  type Note,
  type Solution,
} from "@/data/site";

/* ============================ helpers ============================ */

const childrenOf = (notes: Note[], parent: string | null) =>
  notes.filter((x) => x.parent_id === parent).sort((a, b) => a.sort_order - b.sort_order);

const isDescendant = (notes: Note[], nodeId: string, maybeChild: string | null): boolean => {
  let cur = maybeChild;
  while (cur) {
    if (cur === nodeId) return true;
    cur = notes.find((x) => x.id === cur)?.parent_id ?? null;
  }
  return false;
};

function placeNote(notes: Note[], id: string, parent: string | null, beforeId?: string): Note[] {
  if (isDescendant(notes, id, parent)) return notes;
  const moving = notes.find((x) => x.id === id);
  if (!moving) return notes;
  const siblings = childrenOf(notes, parent).filter((x) => x.id !== id);
  const at = beforeId ? siblings.findIndex((x) => x.id === beforeId) : -1;
  siblings.splice(at < 0 ? siblings.length : at, 0, { ...moving, parent_id: parent });
  const order = new Map(siblings.map((x, i) => [x.id, i + 1]));
  return notes.map((x) =>
    x.id === id ? { ...x, parent_id: parent, sort_order: order.get(x.id) ?? 1 } : order.has(x.id) ? { ...x, sort_order: order.get(x.id)! } : x,
  );
}

const pathOf = (notes: Note[], id: string | null): string[] => {
  const out: string[] = [];
  let cur = id;
  while (cur) {
    const node = notes.find((x) => x.id === cur);
    if (!node) break;
    out.unshift(node.title);
    cur = node.parent_id;
  }
  return out;
};

const CATEGORY_TONE: Record<Solution["category"], { badge: string; stroke: string; dot: string; label: string }> = {
  evt: { badge: "bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-200", stroke: "stroke-amber-600 dark:stroke-amber-400", dot: "border-amber-600 dark:border-amber-400", label: "Event Logs" },
  logparse: { badge: "bg-sky-100 text-sky-900 dark:bg-sky-950 dark:text-sky-200", stroke: "stroke-sky-600 dark:stroke-sky-400", dot: "border-sky-600 dark:border-sky-400", label: "Log Parsing" },
  powershell: { badge: "bg-indigo-100 text-indigo-900 dark:bg-indigo-950 dark:text-indigo-200", stroke: "stroke-indigo-600 dark:stroke-indigo-400", dot: "border-indigo-600 dark:border-indigo-400", label: "PowerShell" },
  python: { badge: "bg-emerald-100 text-emerald-900 dark:bg-emerald-950 dark:text-emerald-200", stroke: "stroke-emerald-600 dark:stroke-emerald-400", dot: "border-emerald-600 dark:border-emerald-400", label: "Python Diagrams" },
};

/* ============================ site map ============================ */

function SiteMap({ nav }: { nav: NavEntry[] }) {
  const goTo = useSite((s) => s.goTo);
  const ROW = 30;
  const rows = nav.reduce((n, t) => n + Math.max(1, t.subpages.length), 0);
  const H = Math.max(rows * ROW + 12, 120);
  let cursor = 6;
  const placed = nav.map((t) => {
    const span = Math.max(1, t.subpages.length) * ROW;
    const top = cursor;
    cursor += span;
    return { t, y: top + span / 2, subs: t.subpages.map((s, i) => ({ s, y: top + i * ROW + ROW / 2 })) };
  });
  const rootY = H / 2;

  return (
    <figure className="min-w-0">
      <div className="relative w-full" style={{ height: H }}>
        <svg className="absolute inset-0 size-full" viewBox={`0 0 100 ${H}`} preserveAspectRatio="none" aria-hidden="true">
          {placed.map(({ t, y, subs }) => (
            <g key={t.id}>
              <path
                d={`M 17 ${rootY} C 26 ${rootY}, 24 ${y}, 32 ${y}`}
                fill="none"
                vectorEffect="non-scaling-stroke"
                className="tw-flow stroke-primary"
                strokeWidth={1.5}
              />
              {subs.map(({ s, y: sy }) => (
                <path
                  key={s.id}
                  d={`M 54 ${y} C 60 ${y}, 58 ${sy}, 64 ${sy}`}
                  fill="none"
                  vectorEffect="non-scaling-stroke"
                  className="stroke-border"
                  strokeWidth={1.25}
                />
              ))}
            </g>
          ))}
        </svg>
        <div
          className="tw-node absolute left-0 flex w-[17%] -translate-y-1/2 items-center gap-1.5 rounded-md border border-border bg-card px-2 py-1.5 font-mono text-xs font-semibold"
          style={{ top: rootY }}
        >
          <span className="tw-pulse size-1.5 shrink-0 rounded-full bg-primary" aria-hidden="true" />
          <span className="truncate">tracewise</span>
        </div>
        {placed.map(({ t, y, subs }) => (
          <div key={t.id}>
            <button
              type="button"
              onClick={() => goTo(t.slug, null)}
              className="tw-node absolute left-[32%] w-[22%] -translate-y-1/2 truncate rounded-md border border-primary/60 bg-card px-2 py-1 text-left text-sm font-medium transition hover:-translate-x-0.5 hover:border-primary focus-visible:outline-2 focus-visible:outline-ring"
              style={{ top: y }}
            >
              {t.label}
            </button>
            {subs.map(({ s, y: sy }) => (
              <button
                key={s.id}
                type="button"
                onClick={() => goTo(t.slug, s.slug)}
                className="absolute left-[64%] max-w-[36%] -translate-y-1/2 truncate rounded px-1.5 py-0.5 text-left text-xs text-foreground/80 transition hover:bg-muted hover:text-foreground focus-visible:outline-2 focus-visible:outline-ring"
                style={{ top: sy }}
              >
                {s.label}
              </button>
            ))}
          </div>
        ))}
      </div>
      <figcaption className="sr-only">Site map generated from the nav_tab and nav_subpage tables</figcaption>
    </figure>
  );
}

/* ============================ notes ============================ */

function TreeRow({
  note,
  depth,
  notes,
  expanded,
  toggle,
}: {
  note: Note;
  depth: number;
  notes: Note[];
  expanded: Set<string>;
  toggle: (id: string) => void;
}) {
  const selected = useSite((s) => s.selectedNoteId);
  const selectNote = useSite((s) => s.selectNote);
  const drag = useDraggable({ id: note.id });
  const drop = useDroppable({ id: `row:${note.id}` });
  const open = expanded.has(note.id);
  const kids = note.is_folder ? childrenOf(notes, note.id) : [];
  const isSel = selected === note.id;

  return (
    <li>
      <div
        ref={drop.setNodeRef}
        className={`group flex items-center gap-0.5 rounded-md pr-1 transition-colors ${
          drop.isOver && !drag.isDragging ? (note.is_folder ? "bg-primary/15 ring-1 ring-primary" : "shadow-[inset_0_2px_0_var(--primary)]") : ""
        } ${isSel ? "bg-muted" : "hover:bg-muted/60"} ${drag.isDragging ? "opacity-40" : ""}`}
        style={{ paddingLeft: depth * 14 }}
      >
        <button
          type="button"
          ref={drag.setNodeRef}
          {...drag.listeners}
          {...drag.attributes}
          aria-label={`Drag ${note.title}`}
          className="cursor-grab rounded p-0.5 text-foreground/40 opacity-60 group-hover:opacity-100 focus-visible:opacity-100 focus-visible:outline-2 focus-visible:outline-ring"
        >
          <GripVertical className="size-3.5" aria-hidden="true" />
        </button>
        {note.is_folder ? (
          <button
            type="button"
            aria-expanded={open}
            aria-label={`${open ? "Collapse" : "Expand"} ${note.title}`}
            onClick={() => toggle(note.id)}
            className="rounded p-0.5 text-foreground/70 focus-visible:outline-2 focus-visible:outline-ring"
          >
            {open ? <ChevronDown className="size-3.5" aria-hidden="true" /> : <ChevronRight className="size-3.5" aria-hidden="true" />}
          </button>
        ) : (
          <span className="w-[18px]" aria-hidden="true" />
        )}
        <button
          type="button"
          aria-current={isSel ? "true" : undefined}
          onClick={() => {
            selectNote(note.id);
            if (note.is_folder && !open) toggle(note.id);
          }}
          className="flex min-w-0 flex-1 items-center gap-1.5 rounded px-1 py-1 text-left text-sm focus-visible:outline-2 focus-visible:outline-ring"
        >
          {note.is_folder ? (
            open ? <FolderOpen className="size-4 shrink-0 text-primary" aria-hidden="true" /> : <Folder className="size-4 shrink-0 text-primary" aria-hidden="true" />
          ) : (
            <FileText className="size-4 shrink-0 text-foreground/50" aria-hidden="true" />
          )}
          <span className={`truncate ${isSel ? "font-medium" : ""}`}>{note.title || "Untitled"}</span>
          {note.is_folder && <span className="ml-auto font-mono text-[10px] text-muted-foreground">{kids.length}</span>}
        </button>
      </div>
      {note.is_folder && open && kids.length > 0 && (
        <ul>
          {kids.map((k) => (
            <TreeRow key={k.id} note={k} depth={depth + 1} notes={notes} expanded={expanded} toggle={toggle} />
          ))}
        </ul>
      )}
    </li>
  );
}

function RootDrop() {
  const { setNodeRef, isOver } = useDroppable({ id: "root" });
  return (
    <div
      ref={setNodeRef}
      className={`mt-1 rounded-md border border-dashed px-2 py-1.5 text-center font-mono text-[11px] text-muted-foreground transition ${
        isOver ? "border-primary bg-primary/10 text-foreground" : "border-border"
      }`}
    >
      / top level
    </div>
  );
}

function StorageNote() {
  const save = useSite((s) => s.save);
  return (
    <div className="flex flex-wrap items-center gap-2 text-xs">
      <Popover>
        <PopoverTrigger asChild>
          <Button variant="ghost" size="xs" className="gap-1 text-foreground/80">
            <HardDrive aria-hidden="true" /> Stored in this browser
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-72 text-sm">
          Notes and site tables are saved in this browser only. They aren&apos;t shared with other people, aren&apos;t synced to other
          browsers or devices, are visible to anyone using this browser profile, and are removed if browser data is cleared.
        </PopoverContent>
      </Popover>
      {save === "saved" && <span className="font-mono text-foreground/70" role="status">Saved</span>}
      {save === "failed" && (
        <span role="alert" className="rounded bg-red-100 px-2 py-0.5 text-red-900 dark:bg-red-950 dark:text-red-200">
          Your latest changes couldn&apos;t be saved in this browser. Keep this page open to avoid losing them.
        </span>
      )}
      {save === "load-failed" && (
        <span role="alert" className="rounded bg-amber-100 px-2 py-0.5 text-amber-900 dark:bg-amber-950 dark:text-amber-200">
          Saved notes couldn&apos;t be loaded. Changes are kept in memory only.
        </span>
      )}
    </div>
  );
}

function NotesSection({ tab }: { tab: NavEntry }) {
  const notes = useSite((s) => s.db.note);
  const mutate = useSite((s) => s.mutate);
  const selectedId = useSite((s) => s.selectedNoteId);
  const selectNote = useSite((s) => s.selectNote);
  const focus = useSite((s) => s.focus);
  const [expanded, setExpanded] = useState<Set<string>>(() => new Set(["f-sp", "f-oos", "f-office", "f-scratch"]));
  const [mode, setMode] = useState<"write" | "split" | "preview">("split");
  const [dropping, setDropping] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const sensors = useSensors(useSensor(PointerSensor, { activationConstraint: { distance: 4 } }), useSensor(KeyboardSensor));

  const selected = notes.find((x) => x.id === selectedId) ?? null;
  const roots = childrenOf(notes, null);
  const folders = notes.filter((x) => x.is_folder);
  const toggle = (id: string) =>
    setExpanded((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });

  // Nav dropdown → open the matching top-level folder
  const handledFocus = useRef(0);
  useEffect(() => {
    if (!focus || focus.at === handledFocus.current) return;
    handledFocus.current = focus.at;
    if (focus.tab !== tab.slug || !focus.sub) return;
    const sub = tab.subpages.find((s) => s.slug === focus.sub);
    const folder = notes.find((x) => x.is_folder && x.parent_id === null && (slugify(x.title) === focus.sub || x.title === sub?.label));
    if (folder) {
      selectNote(folder.id);
      setExpanded((p) => new Set(p).add(folder.id));
    } else if (sub) {
      const id = newNoteId();
      mutate((d) => ({
        ...d,
        note: [...d.note, { id, parent_id: null, title: sub.label, is_folder: true, body_md: "", sort_order: childrenOf(d.note, null).length + 1, updated_at: stamp() }],
      }));
      selectNote(id);
    }
  }, [focus, notes, tab, mutate, selectNote]);

  const targetParent = selected ? (selected.is_folder ? selected.id : selected.parent_id) : null;

  const create = (is_folder: boolean, title: string, body_md = "") => {
    const id = newNoteId();
    mutate((d) => ({
      ...d,
      note: [...d.note, { id, parent_id: targetParent, title, is_folder, body_md, sort_order: childrenOf(d.note, targetParent).length + 1, updated_at: stamp() }],
    }));
    if (targetParent) setExpanded((p) => new Set(p).add(targetParent));
    selectNote(id);
    return id;
  };

  const update = (id: string, patch: Partial<Note>) =>
    mutate((d) => ({ ...d, note: d.note.map((x) => (x.id === id ? { ...x, ...patch, updated_at: stamp() } : x)) }));

  const remove = (id: string) => {
    const doomed = new Set(notes.filter((x) => isDescendant(notes, id, x.id)).map((x) => x.id));
    const removed = notes.filter((x) => doomed.has(x.id));
    mutate((d) => ({ ...d, note: d.note.filter((x) => !doomed.has(x.id)) }));
    selectNote(null);
    toast(`Deleted ${removed.length > 1 ? `${removed.length} items` : "note"}`, {
      action: { label: "Undo", onClick: () => mutate((d) => ({ ...d, note: [...d.note, ...removed] })) },
    });
  };

  const importFiles = async (files: FileList | File[]) => {
    const list = Array.from(files).filter((f) => /\.(md|markdown|txt)$/i.test(f.name));
    if (list.length === 0) {
      toast.error("Only .md, .markdown or .txt files can be imported");
      return;
    }
    const texts = await Promise.all(list.map((f) => f.text().then((t) => ({ f, t }))));
    let lastId = "";
    mutate((d) => {
      let order = childrenOf(d.note, targetParent).length;
      const added = texts.map(({ f, t }) => {
        const heading = /^#\s+(.+)$/m.exec(t)?.[1]?.trim();
        lastId = newNoteId();
        return { id: lastId, parent_id: targetParent, title: heading || f.name.replace(/\.[^.]+$/, ""), is_folder: false, body_md: t, sort_order: ++order, updated_at: stamp() };
      });
      return { ...d, note: [...d.note, ...added] };
    });
    if (lastId) selectNote(lastId);
    toast.success(`Imported ${texts.length} note${texts.length > 1 ? "s" : ""}${targetParent ? ` into ${pathOf(notes, targetParent).join(" / ")}` : ""}`);
  };

  const onDragEnd = (e: DragEndEvent) => {
    const id = String(e.active.id);
    const over = e.over ? String(e.over.id) : null;
    if (!over) return;
    if (over === "root") return mutate((d) => ({ ...d, note: placeNote(d.note, id, null) }));
    const targetId = over.slice(4);
    if (targetId === id) return;
    const target = notes.find((x) => x.id === targetId);
    if (!target) return;
    if (target.is_folder) {
      setExpanded((p) => new Set(p).add(target.id));
      mutate((d) => ({ ...d, note: placeNote(d.note, id, target.id) }));
    } else mutate((d) => ({ ...d, note: placeNote(d.note, id, target.parent_id, target.id) }));
  };

  const download = (n: Note) => {
    try {
      const url = URL.createObjectURL(new Blob([n.body_md], { type: "text/markdown" }));
      const a = document.createElement("a");
      a.href = url;
      a.download = `${slugify(n.title)}.md`;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 1000);
    } catch {
      toast.error("Download isn't available here");
    }
  };

  const isFileDrag = (e: ReactDragEvent) => Array.from(e.dataTransfer.types).includes("Files");

  return (
    <section id={`tab-${tab.slug}`} tabIndex={-1} className="scroll-mt-20 outline-none" aria-labelledby="notes-h">
      <SectionHead index={tab.sort_order} id="notes-h" title={tab.label} fact={`${notes.filter((x) => !x.is_folder).length} notes · ${folders.length} folders`}>
        <StorageNote />
      </SectionHead>

      <div className="grid overflow-hidden rounded-xl border border-border bg-card shadow-sm lg:grid-cols-[300px_1fr]">
        {/* index */}
        <div
          className={`relative border-b border-border p-3 lg:border-r lg:border-b-0 ${dropping ? "bg-primary/5" : ""}`}
          onDragOver={(e) => {
            if (!isFileDrag(e)) return;
            e.preventDefault();
            setDropping(true);
          }}
          onDragLeave={() => setDropping(false)}
          onDrop={(e) => {
            if (!isFileDrag(e)) return;
            e.preventDefault();
            setDropping(false);
            void importFiles(e.dataTransfer.files);
          }}
        >
          <div className="mb-2 flex items-center gap-1">
            <h3 className="mr-auto font-mono text-[11px] font-semibold uppercase tracking-widest text-foreground/70">Index</h3>
            <Button variant="ghost" size="icon-sm" aria-label="New note" onClick={() => create(false, "Untitled note", "# Untitled note\n\n")}>
              <Plus aria-hidden="true" />
            </Button>
            <Button variant="ghost" size="icon-sm" aria-label="New folder" onClick={() => create(true, "New folder")}>
              <FolderPlus aria-hidden="true" />
            </Button>
            <Button variant="ghost" size="icon-sm" aria-label="Import Markdown files" onClick={() => fileRef.current?.click()}>
              <Upload aria-hidden="true" />
            </Button>
            <input
              ref={fileRef}
              type="file"
              accept=".md,.markdown,.txt,text/markdown"
              multiple
              className="sr-only"
              tabIndex={-1}
              aria-hidden="true"
              onChange={(e: ChangeEvent<HTMLInputElement>) => {
                if (e.target.files) void importFiles(e.target.files);
                e.target.value = "";
              }}
            />
          </div>

          <DndContext sensors={sensors} onDragEnd={onDragEnd}>
            <ul className="max-h-[420px] overflow-y-auto pr-1 lg:max-h-[520px]" aria-label="Note index">
              {roots.map((r) => (
                <TreeRow key={r.id} note={r} depth={0} notes={notes} expanded={expanded} toggle={toggle} />
              ))}
            </ul>
            <RootDrop />
          </DndContext>

          <AnimatePresence>
            {dropping && (
              <motion.div
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="pointer-events-none absolute inset-2 grid place-items-center rounded-lg border-2 border-dashed border-primary bg-card/90 text-sm font-medium"
              >
                Drop .md files into {targetParent ? pathOf(notes, targetParent).join(" / ") : "top level"}
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* editor */}
        <div className="min-w-0 p-4 sm:p-5">
          {!selected ? (
            <div className="grid h-full min-h-60 place-items-center text-center text-sm text-foreground/70">
              <div className="space-y-3">
                <p>No note open</p>
                <Button size="sm" onClick={() => create(false, "Untitled note", "# Untitled note\n\n")} className="gap-1.5">
                  <Plus className="size-4" aria-hidden="true" /> New note
                </Button>
              </div>
            </div>
          ) : selected.is_folder ? (
            <FolderView folder={selected} notes={notes} onRename={(t) => update(selected.id, { title: t })} onDelete={() => remove(selected.id)} onNew={() => create(false, "Untitled note", "# Untitled note\n\n")} />
          ) : (
            <div className="flex h-full flex-col gap-3">
              <p className="truncate font-mono text-[11px] text-muted-foreground">{pathOf(notes, selected.parent_id).join(" / ") || "top level"}</p>
              <div className="flex flex-wrap items-center gap-2">
                <Input
                  value={selected.title}
                  onChange={(e) => update(selected.id, { title: e.target.value })}
                  aria-label="Note title"
                  className="h-9 min-w-48 flex-1 border-transparent px-1 font-serif text-xl font-semibold shadow-none md:text-xl focus-visible:border-border"
                />
                <div className="flex rounded-md border border-border p-0.5" role="group" aria-label="Editor layout">
                  {(["write", "split", "preview"] as const).map((m) => (
                    <Button
                      key={m}
                      variant={mode === m ? "secondary" : "ghost"}
                      size="xs"
                      aria-pressed={mode === m}
                      onClick={() => setMode(m)}
                      className={`capitalize ${m === "split" ? "hidden md:inline-flex" : ""}`}
                    >
                      {m}
                    </Button>
                  ))}
                </div>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <Select
                  value={selected.parent_id ?? "__root"}
                  onValueChange={(v) => mutate((d) => ({ ...d, note: placeNote(d.note, selected.id, v === "__root" ? null : v) }))}
                >
                  <SelectTrigger size="sm" className="w-56" aria-label="Move note to folder">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="__root">/ top level</SelectItem>
                    {folders.map((f) => (
                      <SelectItem key={f.id} value={f.id}>
                        {pathOf(notes, f.id).join(" / ")}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button variant="outline" size="sm" className="gap-1.5" onClick={() => download(selected)}>
                  <Download className="size-4" aria-hidden="true" /> .md
                </Button>
                <Button variant="ghost" size="sm" className="gap-1.5" onClick={() => remove(selected.id)}>
                  <Trash2 className="size-4" aria-hidden="true" /> Delete
                </Button>
              </div>
              <div className={`grid min-h-[380px] flex-1 gap-4 ${mode === "split" ? "md:grid-cols-2" : ""}`}>
                {mode !== "preview" && (
                  <Textarea
                    value={selected.body_md}
                    onChange={(e) => update(selected.id, { body_md: e.target.value })}
                    aria-label="Markdown"
                    spellCheck={false}
                    className={`min-h-[380px] resize-y font-mono text-[13px] leading-relaxed ${mode === "split" ? "hidden md:block" : ""}`}
                  />
                )}
                {mode !== "write" && (
                  <div className="tw-prose min-h-[380px] overflow-auto rounded-md border border-border bg-background p-4">
                    <MarkdownText className="text-foreground">{selected.body_md || "*Empty note*"}</MarkdownText>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

function FolderView({ folder, notes, onRename, onDelete, onNew }: { folder: Note; notes: Note[]; onRename: (t: string) => void; onDelete: () => void; onNew: () => void }) {
  const selectNote = useSite((s) => s.selectNote);
  const kids = childrenOf(notes, folder.id);
  return (
    <div className="space-y-4">
      <p className="font-mono text-[11px] text-muted-foreground">{pathOf(notes, folder.parent_id).join(" / ") || "top level"}</p>
      <div className="flex flex-wrap items-center gap-2">
        <Folder className="size-5 text-primary" aria-hidden="true" />
        <Input value={folder.title} onChange={(e) => onRename(e.target.value)} aria-label="Folder name" className="h-9 max-w-sm flex-1 border-transparent px-1 font-serif text-xl font-semibold shadow-none md:text-xl focus-visible:border-border" />
        <Button size="sm" className="gap-1.5" onClick={onNew}>
          <Plus className="size-4" aria-hidden="true" /> Note here
        </Button>
        <Button variant="ghost" size="sm" className="gap-1.5" onClick={onDelete}>
          <Trash2 className="size-4" aria-hidden="true" /> Delete folder
        </Button>
      </div>
      {kids.length === 0 ? (
        <p className="text-sm text-foreground/70">Empty folder</p>
      ) : (
        <ul className="grid gap-2 sm:grid-cols-2">
          {kids.map((k) => (
            <li key={k.id}>
              <button
                type="button"
                onClick={() => selectNote(k.id)}
                className="flex w-full items-start gap-2 rounded-lg border border-border p-3 text-left transition hover:-translate-y-0.5 hover:border-primary/60 hover:shadow-sm focus-visible:outline-2 focus-visible:outline-ring"
              >
                {k.is_folder ? <Folder className="mt-0.5 size-4 text-primary" aria-hidden="true" /> : <FileText className="mt-0.5 size-4 text-foreground/50" aria-hidden="true" />}
                <span className="min-w-0">
                  <span className="block truncate text-sm font-medium">{k.title}</span>
                  <span className="line-clamp-2 text-xs text-foreground/70">
                    {k.is_folder ? `${childrenOf(notes, k.id).length} items` : k.body_md.replace(/[#*`>|-]/g, "").trim().slice(0, 120)}
                  </span>
                </span>
              </button>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}

/* ============================ solutions ============================ */

function FlowGlyph({ sol }: { sol: Solution }) {
  const tone = CATEGORY_TONE[sol.category];
  return (
    <figure className="relative">
      <svg
        className="absolute top-[6px] h-1"
        style={{ left: `${50 / sol.steps.length}%`, right: `${50 / sol.steps.length}%`, width: `${100 - 100 / sol.steps.length}%` }}
        viewBox="0 0 100 2"
        preserveAspectRatio="none"
        aria-hidden="true"
      >
        <line x1="0" y1="1" x2="100" y2="1" vectorEffect="non-scaling-stroke" className={`tw-flow ${tone.stroke}`} strokeWidth="1.5" />
      </svg>
      <ol className="relative flex justify-between" aria-label={`${sol.title} steps`}>
        {sol.steps.map((s) => (
          <li key={s.title} className="flex min-w-0 flex-1 flex-col items-center gap-1.5">
            <span className={`size-[15px] rounded-full border-2 bg-card ${tone.dot}`} aria-hidden="true" />
            <span className="max-w-full truncate px-0.5 text-center font-mono text-xs text-foreground">{s.title}</span>
          </li>
        ))}
      </ol>
    </figure>
  );
}

function SolutionCard({ sol, open, onToggle }: { sol: Solution; open: boolean; onToggle: () => void }) {
  const tone = CATEGORY_TONE[sol.category];
  const copy = async (code: string) => {
    try {
      await navigator.clipboard.writeText(code);
      toast.success("Copied");
    } catch {
      toast.error("Clipboard isn't available here — select the text instead");
    }
  };
  return (
    <motion.article
      layout
      transition={{ type: "spring", stiffness: 260, damping: 30 }}
      className={`group flex flex-col rounded-xl border border-border bg-card p-4 shadow-sm transition-shadow hover:shadow-md ${open ? "sm:col-span-2 lg:col-span-3" : ""}`}
    >
      <div className="flex items-start justify-between gap-2">
        <span className={`rounded-md px-2 py-0.5 font-mono text-[11px] font-medium ${tone.badge}`}>{tone.label}</span>
        <span className="font-mono text-[11px] text-muted-foreground">{sol.steps.length} steps</span>
      </div>
      <h3 className="mt-3 font-serif text-lg leading-snug font-semibold">{sol.title}</h3>
      <p className="mt-1 text-sm text-foreground/80">{sol.summary}</p>
      <div className="mt-3">
        <FlowGlyph sol={sol} />
      </div>
      <div className="mt-2 flex flex-wrap gap-1">
        {sol.tags.map((t) => (
          <span key={t} className="rounded border border-border px-1.5 py-0.5 font-mono text-[10px] text-foreground/80">
            {t}
          </span>
        ))}
      </div>
      <Button variant="ghost" size="sm" className="mt-3 self-start gap-1.5 px-2" aria-expanded={open} onClick={onToggle}>
        <ChevronDown className={`size-4 transition-transform ${open ? "rotate-180" : ""}`} aria-hidden="true" />
        {open ? "Hide steps" : "Show steps"}
      </Button>
      <AnimatePresence initial={false}>
        {open && (
          <motion.ol
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="mt-2 space-y-3 overflow-hidden border-l-2 border-border pl-4"
          >
            {sol.steps.map((s, i) => (
              <li key={s.title} className="relative">
                <span className="absolute -left-[23px] top-0.5 grid size-3.5 place-items-center rounded-full border-2 border-primary bg-card" aria-hidden="true" />
                <p className="text-sm font-medium">
                  <span className="mr-2 font-mono text-xs text-muted-foreground">{String(i + 1).padStart(2, "0")}</span>
                  {s.title}
                </p>
                <p className="text-sm text-foreground/80">{s.detail}</p>
                {s.code && (
                  <div className="relative mt-2">
                    <pre className="overflow-x-auto rounded-md border border-border bg-muted p-3 pr-12 font-mono text-[12px] leading-relaxed">
                      <code>{s.code}</code>
                    </pre>
                    <Button variant="ghost" size="icon-xs" className="absolute right-1.5 top-1.5" aria-label={`Copy ${s.title} ${s.lang ?? ""} code`} onClick={() => void copy(s.code!)}>
                      <Copy aria-hidden="true" />
                    </Button>
                  </div>
                )}
              </li>
            ))}
          </motion.ol>
        )}
      </AnimatePresence>
    </motion.article>
  );
}

function SolutionsSection({ tab }: { tab: NavEntry }) {
  const focus = useSite((s) => s.focus);
  const [filter, setFilter] = useState<string>("all");
  const [openId, setOpenId] = useState<string | null>(null);

  useEffect(() => {
    if (focus?.tab === tab.slug) setFilter(focus.sub ?? "all");
  }, [focus, tab.slug]);

  const shown = filter === "all" ? SOLUTIONS : SOLUTIONS.filter((s) => s.category === filter);
  const activeLabel = tab.subpages.find((s) => s.slug === filter)?.label;

  return (
    <section id={`tab-${tab.slug}`} tabIndex={-1} className="scroll-mt-20 outline-none" aria-labelledby="sol-h">
      <SectionHead index={tab.sort_order} id="sol-h" title={tab.label} fact={`${shown.length} of ${SOLUTIONS.length} workflows${activeLabel ? ` · ${activeLabel}` : ""}`} />
      <div className="mb-4 flex flex-wrap gap-1.5" role="group" aria-label="Filter workflows">
        {[{ slug: "all", label: "All" }, ...tab.subpages].map((s) => (
          <Button key={s.slug} size="sm" variant={filter === s.slug ? "default" : "outline"} aria-pressed={filter === s.slug} onClick={() => setFilter(s.slug)} className="rounded-full">
            {s.label}
          </Button>
        ))}
      </div>
      {shown.length === 0 ? (
        <p className="rounded-xl border border-dashed border-border p-8 text-center text-sm text-foreground/70">No workflows filed under {activeLabel ?? filter} yet</p>
      ) : (
        <motion.div layout className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {shown.map((s) => (
            <SolutionCard key={s.id} sol={s} open={openId === s.id} onToggle={() => setOpenId((o) => (o === s.id ? null : s.id))} />
          ))}
        </motion.div>
      )}
    </section>
  );
}

/* ============================ custom tabs ============================ */

function CustomSection({ tab }: { tab: NavEntry }) {
  const mutate = useSite((s) => s.mutate);
  const selectNote = useSite((s) => s.selectNote);
  const goTo = useSite((s) => s.goTo);
  const notes = useSite((s) => s.db.note);
  const notesSlug = useSite((s) => s.db.nav_tab.find((t) => t.kind === "notes" && t.is_active)?.slug);

  const openFolder = (subLabel: string) => {
    let tabFolder = notes.find((x) => x.is_folder && x.parent_id === null && x.title === tab.label);
    const tabId = tabFolder?.id ?? newNoteId();
    let sub = tabFolder ? notes.find((x) => x.is_folder && x.parent_id === tabId && x.title === subLabel) : undefined;
    const subId = sub?.id ?? newNoteId();
    if (!tabFolder || !sub) {
      mutate((d) => {
        const add: Note[] = [];
        if (!tabFolder) {
          tabFolder = { id: tabId, parent_id: null, title: tab.label, is_folder: true, body_md: "", sort_order: childrenOf(d.note, null).length + 1, updated_at: stamp() };
          add.push(tabFolder);
        }
        if (!sub) {
          sub = { id: subId, parent_id: tabId, title: subLabel, is_folder: true, body_md: "", sort_order: childrenOf(d.note, tabId).length + 1, updated_at: stamp() };
          add.push(sub);
        }
        return { ...d, note: [...d.note, ...add] };
      });
    }
    selectNote(subId);
    if (notesSlug) goTo(notesSlug, null);
  };

  return (
    <section id={`tab-${tab.slug}`} tabIndex={-1} className="scroll-mt-20 outline-none" aria-labelledby={`h-${tab.slug}`}>
      <SectionHead index={tab.sort_order} id={`h-${tab.slug}`} title={tab.label} fact={`${tab.subpages.length} subpages`} />
      {tab.subpages.length === 0 ? (
        <p className="rounded-xl border border-dashed border-border p-8 text-center text-sm text-foreground/70">No subpages yet — add them in Site tables</p>
      ) : (
        <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {tab.subpages.map((s) => {
            const count = notes.filter((x) => x.title === s.label && x.is_folder).reduce((n, f) => n + childrenOf(notes, f.id).length, 0);
            return (
              <li key={s.id} className="flex flex-col rounded-xl border border-border bg-card p-4">
                <p className="font-mono text-[11px] text-muted-foreground">/{tab.slug}/{s.slug}</p>
                <p className="mt-1 font-serif text-lg font-semibold">{s.label}</p>
                <p className="text-xs text-foreground/70">{count} notes</p>
                <Button variant="outline" size="sm" className="mt-3 self-start gap-1.5" onClick={() => openFolder(s.label)} disabled={!notesSlug}>
                  <FolderOpen className="size-4" aria-hidden="true" /> Open in Notes
                </Button>
              </li>
            );
          })}
        </ul>
      )}
    </section>
  );
}

/* ============================ layout ============================ */

function SectionHead({ index, id, title, fact, children }: { index: number; id: string; title: string; fact: string; children?: ReactNode }) {
  return (
    <div className="mb-4 flex flex-wrap items-end gap-x-4 gap-y-2 border-b border-border pb-3">
      <span className="font-mono text-xs text-primary">§{String(index).padStart(2, "0")}</span>
      <h2 id={id} className="font-serif text-2xl font-semibold tracking-tight">
        {title}
      </h2>
      <span className="font-mono text-xs text-foreground/70">{fact}</span>
      {children && <div className="ml-auto">{children}</div>}
    </div>
  );
}

export function HomePage() {
  const db = useSite((s) => s.db);
  const goTo = useSite((s) => s.goTo);
  const nav = useMemo(() => selectNav(db), [db]);
  const noteCount = db.note.filter((x) => !x.is_folder).length;

  return (
    <div className="tw-paper min-h-full">
      <div className="mx-auto max-w-7xl space-y-14 px-4 pt-8 pb-20 sm:px-6">
        <div className="grid items-center gap-6 rounded-2xl border border-border bg-card/80 p-5 shadow-sm backdrop-blur sm:p-6 lg:grid-cols-[minmax(0,320px)_1fr]">
          <div className="space-y-3">
            <p className="font-mono text-[11px] uppercase tracking-[0.2em] text-foreground/70">Chen&apos;s support desk</p>
            <h1 className="font-serif text-3xl leading-tight font-semibold tracking-tight">
              Trace<span className="italic text-primary">wise</span>
            </h1>
            <dl className="grid grid-cols-3 gap-2 border-t border-border pt-3 font-mono text-xs">
              <div>
                <dt className="text-foreground/70">tabs</dt>
                <dd className="text-lg font-semibold">{nav.length}</dd>
              </div>
              <div>
                <dt className="text-foreground/70">notes</dt>
                <dd className="text-lg font-semibold">{noteCount}</dd>
              </div>
              <div>
                <dt className="text-foreground/70">workflows</dt>
                <dd className="text-lg font-semibold">{SOLUTIONS.length}</dd>
              </div>
            </dl>
            <div className="flex flex-wrap gap-2">
              {nav.slice(0, 2).map((t, i) => (
                <Button key={t.id} size="sm" variant={i === 0 ? "default" : "outline"} onClick={() => goTo(t.slug, null)}>
                  {t.label}
                </Button>
              ))}
            </div>
          </div>
          <SiteMap nav={nav} />
        </div>

        <div id="main-work" tabIndex={-1} className="space-y-14 outline-none">
          {nav.map((t) =>
            t.kind === "notes" ? <NotesSection key={t.id} tab={t} /> : t.kind === "solutions" ? <SolutionsSection key={t.id} tab={t} /> : <CustomSection key={t.id} tab={t} />,
          )}
          {nav.length === 0 && <p className="text-center text-sm text-foreground/70">Every tab is hidden — turn one on in Site tables</p>}
        </div>
      </div>
    </div>
  );
}
