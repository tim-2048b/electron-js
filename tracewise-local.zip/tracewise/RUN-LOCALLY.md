# Tracewise – run locally

## Option A: quickest (prebuilt site, no install)
The `prebuilt/` folder is the finished site. Serve it with any static web server
and open the ROOT address (not /index.html):

    cd prebuilt
    python -m http.server 8080        # then open http://localhost:8080/
    # or: npx serve .                 # then open the URL it prints

Opening index.html by double-click (file://) will not work; it needs a server.

## Option B: edit the source (live reload)
Requires Node.js 20+.

    npm install
    npm run dev                       # open the URL Vite prints

Where things live:
- src/data/site.ts        – nav tabs/subpages, seed notes, solution cards, storage
- src/pages/home.tsx      – the page: site map, Notes, Solutions, custom sections
- src/components/app-shell.tsx – top nav with dropdowns + "Site tables" editor
- src/index.css           – colours, fonts, animations
- db/schema.sql           – PostgreSQL tables (nav_tab, nav_subpage, note)

Data is saved in your browser's localStorage, so the local copy and the
online preview keep separate data.
